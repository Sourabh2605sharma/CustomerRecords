package com.waytravels.customerrecords;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@ComponentScan(basepackages= {"com.waytravels"})
@EntityScan(basepackages= {"com.waytravels.model"})
@propertySource(value= {"classpath:/application.properties"})
@EnableJpaRepositories(basepackages= {"com.waytravels.model","com.waytravels.dao","com.waytravels.service"})
public class CustomerRecordsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRecordsApplication.class, args);
	}

}
