package com.waytravels.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer_table")
public class CustomerEntity {

   @Id
   @GeneratedValue
   private Long customerId;
   
   @Column(name="customer_name")
   private String customerName;
   
   @Column(name="favourite_route")
   private String favouriteRoute;
   
   @Column(name="customer_type")
   private String customerType;

public Long getCustomerId() {
return customerId;
}

public void setCustomerId(long i) {
this.customerId = i;
}

public String getCustomerName() {
return customerName;
}

public void setCustomerName(String customerName) {
this.customerName = customerName;
}

public String getFavouriteRoute() {
return favouriteRoute;
}

public void setFavouriteRoute(String favouriteRoute) {
this.favouriteRoute = favouriteRoute;
}

public String getCustomerType() {
return customerType;
}

public void setCustomerType(String customerType) {
this.customerType = customerType;
}
   
}