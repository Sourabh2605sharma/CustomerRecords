package com.waytravels.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.waytravels.model.CustomerEntity;
import com.waytravels.model.JourneyEntity;
import com.waytravels.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

   @Autowired
   CustomerService service;
   
   @PostMapping(path="/addcustomer")
   public ResponseEntity<CustomerEntity> addCustomer(CustomerEntity cu)
                                                   throws Exception {
    CustomerEntity ce=new CustomerEntity();
    ce.setCustomerId(1);
    ce.setCustomerName("Rohan");
    ce.setFavouriteRoute("punetoindore");
    ce.setCustomerType("Normal");
   
       CustomerEntity updated = service.addCustomer(ce);
       return new ResponseEntity<CustomerEntity>(updated, new HttpHeaders(), HttpStatus.OK);
   }
   
   @PostMapping(path="/addjourney")
   public ResponseEntity<JourneyEntity> addJourney(JourneyEntity ju)
                                                   throws Exception {
	   CustomerEntity ce=service.findByActiveCustomer("Rohan");
   	JourneyEntity je=new JourneyEntity();
   	je.setCustomerId(ce.getCustomerId());
   	je.setJourneyDateTime(new Date());
   	je.setRouteName("punetoindore");
   	je.setPrice(service.priceCalculation("punetoindore"));
   	
   
    JourneyEntity updated = service.addJourney(je);
       return new ResponseEntity<CustomerEntity>(updated, new HttpHeaders(), HttpStatus.OK);
   }
   
   
   
   

}