package com.waytravels.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.waytravels.controller.CustomerEntity;
import com.waytravels.controller.CustomerService;
import com.waytravels.controller.List;
import com.waytravels.model.JourneyEntity;

public class CustomerService {
	
		@Autowired
	    CustomerDao cdao;
		@Autowired
		JourneyDao jdao;
	
	
	
	
	
	
	public int priceCalculation(String journey){
	   	CustomerEntity ce=cdao.findByActiveCustomer("Rohan");
	   	
	   	Calender cal=Calender.getInstance();
	   	Date today=new Date();
	   	cal.setTime(today);
	   	List l=jdao.findJourneyListByTime(today,cal.add(Calender.DATE,-2));
	   	if(ce.getFavouriteRoute().equalsIgnoreCase("punetoindore")){
	   		if(l.size>2){
	   			return (200-80);//30% + additional 10% discount
	   		}
	   		return (200-60);// 30% discount
	   	}else if(ce.getCustomerType().equalsIgnoreCase("VIP")){
	   		return 100;
	   	}else{
	   		return 200;
	   	}
	   	
	   	
	   }
	
	public CustomerEntity findByActiveCustomer(String name) throws Exception
    {
		CustomerEntity cus = cdao.findByName(name);
         
        if(cus!=null) {
        	return cus;
        }
        return null;
    }
	
	public CustomerEntity addCustomer(CustomerEntity ce) throws Exception
    {
		CustomerEntity cus = cdao.save(ce);
		return cus;
    }
	public JourneyEntity addJourney(JourneyEntity je) throws Exception
    {
		JourneyEntity j = jdao.save(je);
		return j;
    }
         
}
