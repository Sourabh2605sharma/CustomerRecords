package com.waytravels.dao;

@Repository
public interface JourneyDao CrudRepository<JourneyEntity,Long>{
	
public List<JourneyEntity> findJourneyListByTime(Date d1,Date d2);

}
