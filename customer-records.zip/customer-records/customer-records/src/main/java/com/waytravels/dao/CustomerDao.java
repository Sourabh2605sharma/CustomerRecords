package com.waytravels.dao;
@Repository
public interface CustomerDao extends CrudRepository<CustomerEntity,Long> {
    public CustomerEntity findByName (String name);

}
