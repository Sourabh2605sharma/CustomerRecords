package com.waytravels.model;

import java.util.Date;

@Entity
@Table(name="journey_table")

public class JourneyEntity {
	

	@Column(name="customer_id")
    private Long customerId;
     
	@Column(name="journey_datetime")
    private Date journeyDateTime;
	
	@Column(name="route_name")
    private String routeName;
	
	@Column(name="price")
    private int price;
	
		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		
	     
	    public Long getCustomerId() {
			return customerId;
		}

		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}

		public Date getJourneyDateTime() {
			return journeyDateTime;
		}

		public void setJourneyDateTime(Date journeyDateTime) {
			this.journeyDateTime = journeyDateTime;
		}

		public String getRouteName() {
			return routeName;
		}

		public void setRouteName(String routeName) {
			this.routeName = routeName;
		}

		
	}

}
